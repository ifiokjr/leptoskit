#ifndef _RIVE_ARTBOARD_HOST_HPP_
#define _RIVE_ARTBOARD_HOST_HPP_
#include "rive/refcnt.hpp"
#include "rive/file.hpp"
#include "rive/data_bind_path_referencer.hpp"
#include "rive/math/mat2d.hpp"
#include <stdio.h>
namespace rive
{
class ArtboardInstance;
class DataBind;
class DataContext;
class ViewModelInstance;

class ArtboardHost : public DataBindPathReferencer
{
public:
  virtual size_t artboardCount() = 0;
  virtual ArtboardInstance* artboardInstance(int index = 0) = 0;
  virtual void internalDataContext(rcp<DataContext> dataContext) = 0;
  virtual void bindViewModelInstance(
      rcp<ViewModelInstance> viewModelInstance,
      rcp<DataContext> parent) = 0;
  virtual void clearDataContext() = 0;
  virtual void unbind() = 0;
  virtual void updateDataBinds() = 0;
  virtual void markHostingLayoutDirty(ArtboardInstance* artboardInstance) {}
  // A hosted artboard the host had marked quiet at `row` (see
  // Artboard::quietHostRow) saw something that may change it.
  virtual void hostedRowWoke(Artboard* artboard, uint32_t row) {}
  // The artboard that contains this ArtboardHost
  virtual Artboard* parentArtboard() = 0;
  virtual bool hitTestHost(
      const Vec2D& position,
      bool skipOnUnclipped,
      ArtboardInstance* artboard) = 0;
  virtual Vec2D hostTransformPoint(const Vec2D&, ArtboardInstance*) = 0;
  /// Returns the transform matrix from nested artboard space to parent
  /// artboard space. Unlike hostTransformPoint, this does NOT include
  /// rootTransform.
  virtual Mat2D worldTransformForArtboard(ArtboardInstance*) = 0;
  virtual void markHostTransformDirty() = 0;
  virtual bool isLayoutProvider() { return false; }
  virtual void file(File* value) = 0;
  virtual File* file() const = 0;
  /// The file the hosted artboard was bound in from, when it isn't file().
  virtual const File* foreignFile() const { return nullptr; }

  /// Return this host as a Component, if applicable (e.g., NestedArtboard).
  /// Returns nullptr if the host is not a Component.
  virtual class Component* hostComponent() { return nullptr; }
  virtual void relinkDataContext(rcp<ViewModelInstance> viewModelInstance) {}
  virtual int type() const = 0;

  /// Where ViewModelInstanceValue's change sequence stood the last time this
  /// host skipped advancing its artboards because it was collapsed or
  /// paused, or 0 if it never did. The state machines inside were inactive
  /// while the changes up to it were made, so those changes aren't pending
  /// for them once they run again (see
  /// StateMachineInstance::viewModelValueChanged).
  uint64_t inactiveChangeSequence() const { return m_inactiveChangeSequence; }

protected:
  uint64_t m_inactiveChangeSequence = 0;
};
} // namespace rive

#endif